import React from 'react';
import { DataProvider } from '../../src/contexts/DataContext';
import DataList from '../components/datalist/DataList';

function AboutPage() {
  return (
    <div>AboutPage</div>
  );
}

export default AboutPage;
